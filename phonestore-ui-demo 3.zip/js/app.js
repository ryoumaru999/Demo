
function openSheet() {
  document.getElementById('sheet').style.display = 'block';
}
function closeSheet() {
  document.getElementById('sheet').style.display = 'none';
}
