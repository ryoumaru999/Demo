# No-JS Carousel, Shoe store

A Pen created on CodePen.

Original URL: [https://codepen.io/una/pen/gbMLexO](https://codepen.io/una/pen/gbMLexO).

